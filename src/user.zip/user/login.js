
const Mylogin = () =>{
    return(
        <div className="container mt-4">
            <h1> Login </h1>
        </div>
    )
}

export default Mylogin;