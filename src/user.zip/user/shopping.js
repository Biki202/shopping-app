
const Myhome = () =>{
    return(
        <div className="container mt-4">
            <h1> Shopping Page </h1>
        </div>
    )
}

export default Myhome;