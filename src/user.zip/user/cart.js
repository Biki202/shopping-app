
const Mycart = () =>{
    return(
        <div className="container mt-4">
            <h1> My CART </h1>
        </div>
    )
}

export default Mycart;