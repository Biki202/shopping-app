
const Myregister = () =>{
    return(
        <div className="container mt-4">
            <h1> Register </h1>
        </div>
    )
}

export default Myregister;